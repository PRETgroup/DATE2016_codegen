#ifndef PATH_STATES_H
#define PATH_STATES_H

// States
enum pathStates {idle , replay_cell1 , wait_cell1 , previous_direction1 , replay_cell2 , wait_cell2 , previous_direction2, annihilate};

#endif